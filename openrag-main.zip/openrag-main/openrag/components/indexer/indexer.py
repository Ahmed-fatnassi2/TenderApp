import asyncio
import gc
import os
import traceback
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import ray
import torch
from config import load_config
from langchain_core.documents.base import Document

from .chunker import BaseChunker, ChunkerFactory
from .utils import serialize_file

config = load_config()
save_uploaded_files = os.environ.get("SAVE_UPLOADED_FILES", "true").lower() == "true"

POOL_SIZE = config.ray.pool_size
MAX_TASKS_PER_WORKER = config.ray.max_tasks_per_worker


@ray.remote(
    max_concurrency=config.ray.indexer.concurrency_groups.default,
    max_task_retries=config.ray.indexer.max_task_retries,
    concurrency_groups={
        "update": config.ray.indexer.concurrency_groups.update,
        "search": config.ray.indexer.concurrency_groups.search,
        "delete": config.ray.indexer.concurrency_groups.delete,
        "insert": config.ray.indexer.concurrency_groups.insert,
        "chunk": config.ray.indexer.concurrency_groups.chunk,
        "serialize": config.ray.indexer.concurrency_groups.serialize,
    },
)
class Indexer:
    def __init__(self):
        from utils.logger import get_logger

        self.config = load_config()
        self.logger = get_logger()

        # Initialize chunker
        self.chunker: BaseChunker = ChunkerFactory.create_chunker(self.config)

        self.default_partition = "_default"
        self.enable_insertion = self.config.vectordb.enable
        self.handle = ray.get_actor("Indexer", namespace="openrag")

        self.logger.info("Indexer actor initialized.")

    @ray.method(concurrency_group="chunk")
    async def chunk(self, doc: Document, file_path: str, task_id: str = None) -> list[Document]:
        chunks = await self.chunker.split_document(doc, task_id)
        return chunks

    @ray.method(concurrency_group="serialize")
    async def serialize_file(
        self,
        path: str,
        metadata: dict = {},
        task_id: str = None,
    ):
        # Serialize
        doc = await serialize_file(task_id, path, metadata=metadata)
        return doc

    async def add_file(
        self,
        path: str,
        metadata: dict | None = None,
        partition: str | None = None,
        user: dict | None = None,
        workspace_ids: list[str] | None = None,
        replace: bool = False,
    ):
        task_state_manager = ray.get_actor("TaskStateManager", namespace="openrag")
        task_id = ray.get_runtime_context().get_task_id()
        metadata = metadata or {}

        file_id = metadata.get("file_id", None)
        log = self.logger.bind(file_id=file_id, partition=partition, task_id=task_id)
        log.info("Queued file for indexing.")
        try:
            # Set task details
            user_metadata = {k: v for k, v in metadata.items() if k not in {"file_id", "source"}}

            await task_state_manager.set_details.remote(
                task_id,
                file_id=metadata.get("file_id"),
                partition=partition,
                metadata=user_metadata,
                user_id=user.get("id"),
            )

            # Check/normalize partition
            partition = self._check_partition_str(partition)
            metadata = {**metadata, "partition": partition}

            # Serialize
            doc = await self.handle.serialize_file.remote(path=path, metadata=metadata, task_id=task_id)

            # Chunk
            if doc:
                await task_state_manager.set_state.remote(task_id, "CHUNKING")
                chunks = await self.handle.chunk.remote(doc, str(path), task_id)
            else:
                log.warning("No document returned from serialization; skipping indexing.")
                chunks = []

            if self.enable_insertion:
                if chunks:
                    await task_state_manager.set_state.remote(task_id, "INSERTING")
                    if replace:
                        # PUT flow: PG File row already exists; insert new Milvus chunks
                        # and update PG metadata in-place (no File row creation).
                        await self.handle.replace_file_documents.remote(chunks, user=user)
                    else:
                        await self.handle.insert_documents.remote(chunks, user=user)
                    log.info(f"Document {path} indexed successfully")
                else:
                    log.debug("No chunks to insert !!! Potentially the uploaded file is empty")
            else:
                log.info(f"Vectordb insertion skipped (enable_insertion={self.enable_insertion}).")

            # Mark task as completed before workspace association so the file
            # record exists in the DB before we reference it from workspace_files.
            await task_state_manager.set_state.remote(task_id, "COMPLETED")

            # Associate with workspaces only after successful indexing (best-effort).
            # Not needed for replace=True since the PG row (and its workspace FKs) is preserved.
            if workspace_ids and not replace:
                vectordb = ray.get_actor("Vectordb", namespace="openrag")
                try:
                    await asyncio.gather(
                        *[vectordb.add_files_to_workspace.remote(ws_id, [file_id]) for ws_id in workspace_ids]
                    )
                except Exception as ws_err:
                    log.warning(
                        "Failed to associate file with workspaces; file is indexed but workspace links may be incomplete",
                        error=str(ws_err),
                        workspace_ids=workspace_ids,
                    )

        except Exception as e:
            tb = "".join(traceback.format_exception(type(e), e, e.__traceback__))
            log.error(f"Task {task_id} failed in add_file\n{tb}")
            await task_state_manager.set_failed_if_not_cancelled.remote(task_id, tb)
            raise

        finally:
            if torch.cuda.is_available():
                gc.collect()
                torch.cuda.empty_cache()
                torch.cuda.ipc_collect()
            try:
                # Cleanup input file
                if not save_uploaded_files:
                    Path(path).unlink(missing_ok=True)
                    log.debug(f"Deleted input file: {path}")
            except Exception as cleanup_err:
                log.warning(f"Failed to delete input file {path}: {cleanup_err}")
        return True

    @ray.method(concurrency_group="insert")
    async def insert_documents(self, chunks, user):
        vectordb = ray.get_actor("Vectordb", namespace="openrag")
        await vectordb.async_add_documents.remote(chunks, user)

    @ray.method(concurrency_group="insert")
    async def replace_file_documents(self, chunks, user):
        """Insert chunks for an existing file after its old Milvus chunks have been deleted.

        Unlike insert_documents, this calls add_documents_for_existing_file which
        updates the PostgreSQL File row in-place instead of creating a new one.
        """
        vectordb = ray.get_actor("Vectordb", namespace="openrag")
        await vectordb.add_documents_for_existing_file.remote(chunks, user)

    @ray.method(concurrency_group="delete")
    async def delete_file(self, file_id: str, partition: str) -> bool:
        log = self.logger.bind(file_id=file_id, partition=partition)
        vectordb = ray.get_actor("Vectordb", namespace="openrag")
        if not self.enable_insertion:
            log.error("Vector database is not enabled, but delete_file was called.")
            return False

        try:
            await vectordb.delete_file.remote(file_id, partition)
            log.info("Deleted file from partition.", file_id=file_id, partition=partition)

        except Exception as e:
            log.error("Error in delete_file", error=str(e))
            raise

    @ray.method(concurrency_group="update")
    async def update_file_metadata(
        self,
        file_id: str,
        metadata: dict,
        partition: str,
        user: dict | None = None,
    ):
        log = self.logger.bind(file_id=file_id, partition=partition)
        vectordb = ray.get_actor("Vectordb", namespace="openrag")
        if not self.enable_insertion:
            log.error("Vector database is not enabled, but update_file_metadata was called.")
            return

        try:
            # Upsert metadata in-place: updates Milvus chunks (preserving vectors,
            # no re-embedding) and the PostgreSQL file record. No delete step, so
            # workspace FK references and file_count are never disturbed.
            await vectordb.upsert_file_metadata.remote(file_id, partition, metadata)
            log.info("Metadata updated for file.")
        except Exception as e:
            log.error("Error in update_file_metadata", error=str(e))
            raise

    @ray.method(concurrency_group="update")
    async def copy_file(
        self,
        file_id: str,
        metadata: dict,
        partition: str,
        user: dict | None = None,
    ):
        log = self.logger.bind(file_id=file_id, partition=partition)
        vectordb = ray.get_actor("Vectordb", namespace="openrag")
        if not self.enable_insertion:
            log.error("Vector database is not enabled, but copy_file was called.")
            return

        try:
            docs = await vectordb.get_file_chunks.remote(file_id, partition)
            for doc in docs:
                doc.metadata.update(metadata)

            await vectordb.async_add_documents.remote(docs, user=user)

            log.info(
                "File copy completed",
                file_id=file_id,
                partition=partition,
                new_file_id=metadata.get("file_id"),
                new_partition=metadata.get("partition"),
            )
        except Exception as e:
            log.error("Error in copy_file", error=str(e))
            raise

    @ray.method(concurrency_group="search")
    async def asearch(
        self,
        query: str,
        top_k: int = 5,
        similarity_threshold: float = 0.60,
        partition: str | list[str] | None = None,
        filter: str | None = None,
        filter_params: dict | None = None,
    ) -> list[Document]:
        partition_list = self._check_partition_list(partition)
        vectordb = ray.get_actor("Vectordb", namespace="openrag")
        return await vectordb.async_search.remote(
            query=query,
            partition=partition_list,
            top_k=top_k,
            similarity_threshold=similarity_threshold,
            filter=filter,
            filter_params=filter_params,
        )

    def _check_partition_str(self, partition: str | None) -> str:
        if partition is None:
            self.logger.warning("partition not provided; using default.")
            return self.default_partition
        if not isinstance(partition, str):
            raise ValueError("Partition must be a string.")
        return partition

    def _check_partition_list(self, partition: str | list[str] | None) -> list[str]:
        if partition is None:
            self.logger.warning("partition not provided; using default.")
            return [self.default_partition]
        if isinstance(partition, str):
            return [partition]
        if isinstance(partition, list) and all(isinstance(p, str) for p in partition):
            return partition
        raise ValueError("Partition must be a string or a list of strings.")


@dataclass
class TaskInfo:
    state: str | None = None
    error: str | None = None
    details: dict[str, Any] = field(default_factory=dict)
    object_ref: ray.ObjectRef | None = None


@ray.remote(concurrency_groups={"set": 1000, "get": 1000, "queue_info": 1000})
class TaskStateManager:
    def __init__(self):
        self.tasks: dict[str, TaskInfo] = {}
        self.user_index: dict[int, set[str]] = {}
        self.lock = asyncio.Lock()

    async def _ensure_task(self, task_id: str) -> TaskInfo:
        """Helper to get-or-create the TaskInfo object under lock."""
        if task_id not in self.tasks:
            self.tasks[task_id] = TaskInfo()
        return self.tasks[task_id]

    @ray.method(concurrency_group="set")
    async def set_state(self, task_id: str, state: str):
        async with self.lock:
            info = await self._ensure_task(task_id)
            info.state = state

    @ray.method(concurrency_group="set")
    async def set_error(self, task_id: str, tb_str: str):
        async with self.lock:
            info = await self._ensure_task(task_id)
            info.error = tb_str

    @ray.method(concurrency_group="set")
    async def set_failed_if_not_cancelled(self, task_id: str, tb_str: str) -> bool:
        """Atomically set state to FAILED and record the traceback, unless the
        task is already CANCELLED.  Returns True if the state was set to FAILED."""
        async with self.lock:
            info = self.tasks.get(task_id)
            if info is None or info.state == "CANCELLED":
                return False
            info.state = "FAILED"
            info.error = tb_str
            return True

    @ray.method(concurrency_group="set")
    async def set_details(
        self,
        task_id: str,
        *,
        file_id: str,
        partition: int,
        metadata: dict,
        user_id: int,
    ):
        async with self.lock:
            info = await self._ensure_task(task_id)
            info.details = {
                "file_id": file_id,
                "partition": partition,
                "metadata": metadata,
                "user_id": user_id,
            }
            self.user_index.setdefault(user_id, set()).add(task_id)

    @ray.method(concurrency_group="set")
    async def set_object_ref(self, task_id: str, object_ref: dict):
        async with self.lock:
            info = await self._ensure_task(task_id)
            info.object_ref = object_ref

    @ray.method(concurrency_group="get")
    async def get_state(self, task_id: str) -> str | None:
        async with self.lock:
            info = self.tasks.get(task_id)
            return info.state if info else None

    @ray.method(concurrency_group="get")
    async def get_error(self, task_id: str) -> str | None:
        async with self.lock:
            info = self.tasks.get(task_id)
            return info.error if info else None

    @ray.method(concurrency_group="get")
    async def get_details(self, task_id: str) -> dict | None:
        async with self.lock:
            info = self.tasks.get(task_id)
            return info.details if info else None

    @ray.method(concurrency_group="get")
    async def get_object_ref(self, task_id: str) -> dict | None:
        async with self.lock:
            info = self.tasks.get(task_id)
            return info.object_ref if info else None

    @ray.method(concurrency_group="queue_info")
    async def get_all_states(self) -> dict[str, str]:
        async with self.lock:
            return {tid: info.state for tid, info in self.tasks.items()}

    @ray.method(concurrency_group="queue_info")
    async def get_all_info(self) -> dict[str, dict]:
        async with self.lock:
            return {
                task_id: {
                    "state": info.state,
                    "error": info.error,
                    "details": info.details,
                }
                for task_id, info in self.tasks.items()
            }

    @ray.method(concurrency_group="queue_info")
    async def get_all_user_info(self, user_id: int) -> dict[str, dict]:
        async with self.lock:
            task_ids = self.user_index.get(user_id, set())
            return {
                tid: {
                    "state": self.tasks[tid].state,
                    "error": self.tasks[tid].error,
                    "details": self.tasks[tid].details,
                }
                for tid in task_ids
                if tid in self.tasks
            }

    @ray.method(concurrency_group="queue_info")
    async def get_pool_info(self) -> dict[str, int]:
        return {
            "pool_size": POOL_SIZE,
            "max_tasks_per_worker": MAX_TASKS_PER_WORKER,
            "total_capacity": POOL_SIZE * MAX_TASKS_PER_WORKER,
        }

    @ray.method(concurrency_group="queue_info")
    async def get_user_pending_task_count(self, user_id: int) -> int:
        """Count tasks for a user that are not yet COMPLETED or FAILED."""
        async with self.lock:
            task_ids = self.user_index.get(user_id, set())
            pending_states = {"QUEUED", "SERIALIZING", "CHUNKING", "INSERTING"}
            count = 0
            for tid in task_ids:
                info = self.tasks.get(tid)
                if info and info.state in pending_states:
                    count += 1
            return count
